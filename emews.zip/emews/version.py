'''
emews versioning info

Note: this file is used as a reference to obtain the <root> path for the emews project directory
structure.  It must recide in the root project (emews) directory.
'''
__version__ = "0.32"

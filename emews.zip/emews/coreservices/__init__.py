'''
Specifies which CORE services are loaded.
'''
#__all__ = ["emewsdaemon"]
